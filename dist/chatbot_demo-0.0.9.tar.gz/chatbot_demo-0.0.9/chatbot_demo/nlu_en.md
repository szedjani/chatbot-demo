## intent:ltd
- ltd
- limited

## intent:plc
- plc
- public
- limited public

## intent:shareholder
- shareholder
