name = "chatbot-demo"

from package.tagger import Tagger