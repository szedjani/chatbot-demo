## intent:ltd
- GmbH

## intent:plc
- AG

## intent:shareholder
- Gesellschafter
- Mehrheitseigner
