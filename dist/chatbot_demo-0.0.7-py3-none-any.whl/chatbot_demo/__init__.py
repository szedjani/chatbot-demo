name = "chatbot_demo"

from chatbot_demo.tagger import Tagger
